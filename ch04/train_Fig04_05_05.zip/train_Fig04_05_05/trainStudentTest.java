// Fig. 4.5: trainStudentTest.java
// // Create and test Student objects.
package ch04.train_Fig04_05_05;

public class trainStudentTest
{
    public static void main(String[] args)
    {
        trainStudent accountA = new trainStudent("tom", 40.4);
        trainStudent accountB = new trainStudent("tina", 80.9);

        System.out.printf("aaaName: %s     Grade: %s%n",
                accountA.getName(), accountA.getStudentGrade());

        System.out.printf("Name: %s     Grade: %s%n",
                accountB.getName(), accountB.getStudentGrade());

        System.out.print("set new to accountA: mike, 66.6");
        accountA.setName("mike");
        accountA.setAverage(66.6);
        System.out.printf("Name: %s     Grade: %s%n",
                accountA.getName(), accountA.getStudentGrade());

    }
}
