// Fig. 4.4: trainStudent.java
// Student class that stores a student name and average.
package ch04.train_Fig04_05_05;

public class trainStudent 
{
    String name;
    double average;

    // constructor
    public trainStudent(String aName, double anAverage)
    {
        this.name = aName;

        if (anAverage > 0)
            if (anAverage <= 100)
                this.average = anAverage;
    }

    // set student name
    public void setName(String studentName)
    {
        this.name = studentName;
    }

    // get student name
    public String getName()
    {
        return this.name;
    }

    // set average
    public void setAverage(double anAverageAmount)
    {
        if (anAverageAmount > 0)
            if (anAverageAmount <= 100)
                this.average = anAverageAmount;
    }

    // get average 
    public double getAverage()
    {
        return this.average;
    }
    
    // get sutdent grade letter
    public String getStudentGrade()
    {
        String letter = "";

        if (this.average > 90)
            letter = "F";
        else if (this.average > 50)
            letter = "E";
        else if (this.average > 10)
            letter = "D";
        else
            letter = "C";

        return letter;
    }

} // end class Student

